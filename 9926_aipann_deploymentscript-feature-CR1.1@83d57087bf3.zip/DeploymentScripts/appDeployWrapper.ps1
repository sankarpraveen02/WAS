Write-Host "`t[usage]: [-u | --help] for help to run this script.`n"

if (($args.Count -eq 1) -AND (($args[0] -eq "-u" ) -OR ( $args[0] -eq "--help")))
{
	Write-Host "`t This script takes 10 parameters"
	Write-Host "`t`t Parameter 1: Application Name"
	Write-Host "`t`t Parameter 2: Context Root"
	Write-Host "`t`t Parameter 3: War File Path"
	Write-Host "`t`t Parameter 5: Cluster Name"
	Write-Host "`t`t Parameter 6: WAS User"
	Write-Host "`t`t Parameter 7: WAS Password"
	Write-Host "`t`t Parameter 10: Webserver"
	Write-Host "`t`t Parameter 11: Web Node Name"
	Write-Host "`t`t Parameter 12: Config path"
	exit 0
}
#Assigning input parameters
 if ($args.Count -le 10 )
 {
	Write-Host "Deployment Error : Incorrect Number of Parameters Provided"
	exit 1
}
else 
{
	$APP_NAME=$args[0]
	$CONTEXT_ROOT=$args[1]
	$WAR_PATH=$args[2]
	$msg="[Deployment] "
	$CLUSTER_NAME=$args[3]
	$WEBSERVER=$args[4]
	$WEB_NODE_NAME=$args[5]
        $WEBSERVER1=$args[6]
	$WEB_NODE_NAME1=$args[7]
	$CONFIG_PATH=$args[8]
	$WAS_USER=$args[9]
	$WAS_PASSWORD=$args[10]
	cd ${CONFIG_PATH}
	$WSADMIN_SCRIPT_PATH=$args[11]
 	$INSTALL_PATH=$args[12]
	$SCRIPT_PATH=${CONFIG_PATH}
}

if ($WEBSERVER1 -eq ""){
 	$WEBSERVER1="null"
	$WEB_NODE_NAME1="null"

}

#check if war file exists
if (!(Test-Path ${WAR_PATH}) ){
	Write-Host "${msg}WAR file doesnot exist"
	exit 1
}

#show variable values
Write-Host "${msg}Application Name :${APP_NAME}"
Write-Host "${msg}Context Root :${CONTEXT_ROOT}"
Write-Host "${msg}WAR Path :${WAR_PATH}"
Write-Host "${msg}Cluster Name :${CLUSTER_NAME}"
Write-Host "${msg}Webserver Name :${WEBSERVER}"
Write-Host "${msg}Webserver Node :${WEB_NODE_NAME}"
Write-Host "${msg}Webserver Name1 :${WEBSERVER1}"
Write-Host "${msg}Webserver Node1 :${WEB_NODE_NAME1}"
Write-Host "${msg}Config Path :${CONFIG_PATH}"
Write-Host "${msg}WAS User ID :${WAS_USER}"
Write-Host "${msg}WAS Password :${WAS_PASSWORD}"
Write-Host "${msg}WSAdmin Script Path :${WSADMIN_SCRIPT_PATH}"
Write-Host "${msg}Installation Path :${INSTALL_PATH}"

#setting wsadmin script path

Write-Host "${msg}: Application status check start "

& ${WSADMIN_SCRIPT_PATH} -username ${WAS_USER} -password ${WAS_PASSWORD} -lang jython -f ${SCRIPT_PATH}/appstatus.jython ${APP_NAME} ${CLUSTER_NAME}

$result = $LastExitCode

cd ${CONFIG_PATH}

switch(${result})
{
	
0 {



Start-Sleep -s 30

& ${WSADMIN_SCRIPT_PATH} -username ${WAS_USER} -password ${WAS_PASSWORD} -javaoption -Xmx512m -lang jython -f ${SCRIPT_PATH}/appDeploy.py ${APP_NAME} ${CONTEXT_ROOT} ${WAR_PATH} ${CLUSTER_NAME} ${WEBSERVER} ${WEB_NODE_NAME} ${WEBSERVER1} ${WEB_NODE_NAME1} update ${INSTALL_PATH}

if ($? -eq 0)
{
	echo "[Deployment]: ERROR - Failed to update application"
	echo "[Deployment]: ERROR - Deployment Failed "
	exit 1
}
Start-Sleep -s 30




}

	
	1 {
	
	
Start-Sleep -s 30

	
& ${WSADMIN_SCRIPT_PATH} -username ${WAS_USER} -password ${WAS_PASSWORD} -javaoption -Xmx512m -lang jython -f ${SCRIPT_PATH}/appDeploy.py ${APP_NAME} ${CONTEXT_ROOT} ${WAR_PATH} ${CLUSTER_NAME} ${WEBSERVER} ${WEB_NODE_NAME} ${WEBSERVER1} ${WEB_NODE_NAME1} update ${INSTALL_PATH}
if ($? -eq 0)
{
	echo "Deployment: ERROR - Failed to update application"
	echo "Deployment: ERROR - Deployment Failed "
	exit 1
}
Start-Sleep -s 30



}
	
	2 {
		
		& ${WSADMIN_SCRIPT_PATH} -username ${WAS_USER} -password ${WAS_PASSWORD} -lang jython -f ${SCRIPT_PATH}/jvmStartStop.py stop ${CLUSTER_NAME}

if ($? -eq 0)
{
	echo "[Deployment]: ERROR - Failed to stop JVM"
	echo "[Deployment]: ERROR - Deployment Failed "
	exit 1
}
Start-Sleep -s 30

& ${WSADMIN_SCRIPT_PATH} -username ${WAS_USER} -password ${WAS_PASSWORD} -javaoption -Xmx512m -lang jython -f ${SCRIPT_PATH}/appDeploy.py ${APP_NAME} ${CONTEXT_ROOT} ${WAR_PATH} ${CLUSTER_NAME} ${WEBSERVER} ${WEB_NODE_NAME} ${WEBSERVER1} ${WEB_NODE_NAME1} install ${INSTALL_PATH}

if ($? -eq 0)
{
	echo "Deployment: ERROR - Failed to install application"
	echo "Deployment: ERROR - Deployment Failed "
	exit 1
}
Start-Sleep -s 30
& ${WSADMIN_SCRIPT_PATH} -username ${WAS_USER} -password ${WAS_PASSWORD} -lang jython -f ${SCRIPT_PATH}/jvmStartStop.py start ${CLUSTER_NAME}

if ($? -eq 0)
{
	echo "[Deployment]: ERROR - Failed to stop JVM"
	echo "[Deployment]: ERROR - Deployment Failed "
	exit 1
}
Start-Sleep -s 30

}
	default { 
            exit 1
            }
 
}

