import sys
import os
import time
import string
import wsadminlib as WSAL
#======================================

msg = "[Deployment] "


if len(sys.argv) < 1:
	print msg_err + "Incorrect number of parameters passed"
	sys.exit(1)
else:
	taskType = sys.argv[0]
	clusterName = sys.argv[1]

def startJVM():
	try:
		print msg + "Starting JVM"
                cellName = WSAL.getCellName()
		cluster = AdminControl.completeObjectName('cell='+cellName+',type=Cluster,name='+clusterName+',*')
		print AdminControl.getAttribute(cluster, 'state')
  		print AdminControl.invoke(cluster ,'start')
  		time.sleep(30)
  		print "Cluster started"
		print msg + "JVM started successfully"
	except Exception, err:
		err = sys.exc_info()[1]
		print msg_err + "Failed starting JVM \n\t" + str(err)
		sys.exit(1)

def stopJVM():
	try:
		print msg + "Stopping JVM"
                clusterID = AdminConfig.getid("/ServerCluster:"+clusterName+"/")
                clusterList = AdminConfig.list('ClusterMember', clusterID)
                servers=clusterList.splitlines()
                for serverID in servers:
                   nodeName = AdminConfig.showAttribute(serverID, 'nodeName')
                   serverName = AdminConfig.showAttribute(serverID, 'memberName')
		   AdminControl.invoke(AdminControl.queryNames("type=Server,node="+nodeName+",process="+serverName+",*"),'stop')
		print msg + "JVM stopped successfully."
	except Exception, err:
		err = sys.exc_info()[1]
		print msg_err + "Failed stopping JVM \n\t" + str(err)
		sys.exit(1)

if taskType == "start": 
	startJVM()
else:
	if taskType == "stop":
                if WSAL.isClusterStarted(clusterName) :
		   stopJVM()
	else:
		print msg + "Task type not recognized"
		sys.exit(1)

