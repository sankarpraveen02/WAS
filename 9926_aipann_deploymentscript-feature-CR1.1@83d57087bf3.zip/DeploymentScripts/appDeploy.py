import sys
import os
import time
import string
import wsadminlib as WSAL
#======================================

msg = "[Deployment] "
# Application configuration constants

if len(sys.argv) < 5:
	print msg + "Incorrect number of parameters passed"
	sys.exit(1)
else:
	appName = sys.argv[0]
	contextRoot = sys.argv[1]
	warPath = sys.argv[2]
	clusterName = sys.argv[3]
	webServer = sys.argv[4]
	webNodeName = sys.argv[5]
        webServer1 = sys.argv[6]
	webNodeName1 = sys.argv[7]
	action = sys.argv[8]
	installPath = sys.argv[9]
        cellName = WSAL.getCellName()
	print msg + "Application Name: " + appName
	print msg + "Contextroot: " + contextRoot
	print msg + "war_path: " + warPath
	print msg + "clusterName : " + clusterName  
	print msg + "Wbserver Name: " + webServer 
	print msg + "wbnode Name: " + webNodeName
        print msg + "Wbserver Name1: " + webServer1 
	print msg + "wbnode Name1: " + webNodeName1  
	print msg + "action Name: " + action 
        print msg + "Cell name: " + cellName
	print msg + "Installation Path: " + installPath

print "#########################################################"

def saveSyncConfiguration(appName): 
	try:
		print msg + "Saving Configuration"
		AdminConfig.save()
		print msg + "Configuration Saved"
		print msg + "Synchronizing"
                clusterID = AdminConfig.getid("/ServerCluster:"+clusterName+"/")
                clusterList = AdminConfig.list('ClusterMember', clusterID)
                servers=clusterList.splitlines()
                for serverID in servers:
                   nodeName = AdminConfig.showAttribute(serverID, 'nodeName')
		   AdminControl.invoke(AdminControl.completeObjectName('type=NodeSync,node='+nodeName+',*'), 'sync')
		print msg + "Synchronization Completed"
	except Exception, err:
		err = sys.exc_info()[1]
		print msg + "saveSyncConfiguration Failed for application " + appName + "\n\t" + str(err)
		sys.exit(1)


if action == "install":
		print msg + "Installing Application " + appName
		if webServer1 == "null":
			AdminApp.install(warPath, "[ -nopreCompileJSPs -distributeApp -nouseMetaDataFromBinary -nodeployejb -appname " + appName + " -installed.ear.destination " + installPath + " -createMBeansForResources -noreloadEnabled -nodeployws -validateinstall warn -noprocessEmbeddedConfig -filepermission .*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755 -noallowDispatchRemoteInclude -noallowServiceRemoteInclude -asyncRequestDispatchType DISABLED -nouseAutoLink -contextroot "+contextRoot+" -MapModulesToServers [['.*' '.*' 'WebSphere:cell=" + cellName + ",cluster=" + clusterName + "+WebSphere:cell=" + cellName + ",node=" + webNodeName + ",server=" + webServer +"']] -MapWebModToVH [['.*' '.*' 'default_host']]]" )
		elif webServer1 != "null":
			AdminApp.install(warPath, "[ -nopreCompileJSPs -distributeApp -nouseMetaDataFromBinary -nodeployejb -appname " + appName + " -installed.ear.destination " + installPath + " -createMBeansForResources -noreloadEnabled -nodeployws -validateinstall warn -noprocessEmbeddedConfig -filepermission .*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755 -noallowDispatchRemoteInclude -noallowServiceRemoteInclude -asyncRequestDispatchType DISABLED -nouseAutoLink -contextroot "+contextRoot+" -MapModulesToServers [['.*' '.*' 'WebSphere:cell=" + cellName + ",cluster=" + clusterName + "+WebSphere:cell=" + cellName + ",node=" + webNodeName + ",server=" + webServer +"+WebSphere:cell=" + cellName + ",node=" + webNodeName1 + ",server=" + webServer1 +"']] -MapWebModToVH [['.*' '.*' 'default_host']]]" )
		else:
			print "Webservers not available"
			sys.exit(1)
		print "Installed"
                saveSyncConfiguration(appName)
else:
		print msg + "update Application " + appName
		clusterID = AdminConfig.getid("/ServerCluster:"+clusterName+"/")
                clusterList = AdminConfig.list('ClusterMember', clusterID)
                servers=clusterList.splitlines()
                for serverID in servers:
                   nodeName = AdminConfig.showAttribute(serverID, 'nodeName')
                   print msg + "nodeName " + nodeName
                   AdminControl.invoke(AdminControl.queryNames('node='+ nodeName +',type=NodeSync,*'),'setAutoSyncEnabled','false')
		AdminConfig.save()
		print msg + "Sync Disabled " + appName
		AdminApp.update(appName, 'app', "[-operation update -contents "+warPath+" -contextroot "+contextRoot+" -usedefaultbindings -nodeployejb ]")
		AdminConfig.save()
		print msg + "Update App on Cluster started " + appName
		AdminTask.updateAppOnCluster(['-ApplicationNames', appName, '-timeout', '600'])
		print msg + "Sync enabled " + appName
		clusterID = AdminConfig.getid("/ServerCluster:"+clusterName+"/")
                clusterList = AdminConfig.list('ClusterMember', clusterID)
                servers=clusterList.splitlines()
                for serverID in servers:
                   nodeName = AdminConfig.showAttribute(serverID, 'nodeName')
                   AdminControl.invoke(AdminControl.queryNames('node='+ nodeName +',type=NodeSync,*'),'setAutoSyncEnabled','true')
print "#################################################"
